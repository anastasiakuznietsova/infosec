import hashlib


def bits_padding(message_bytes):
    """Pad message according to MD5 specification"""
    original_length = len(message_bytes) * 8  # length in bits

    # Append the '1' bit (plus zero padding to make it a full byte: 0x80 = 10000000)
    message_bytes += b'\x80'

    # Append zeros until message length ≡ 448 (mod 512) bits, or 56 (mod 64) bytes
    while len(message_bytes) % 64 != 56:
        message_bytes += b'\x00'

    # Append original length as 64-bit little-endian integer
    message_bytes += original_length.to_bytes(8, byteorder='little')
    return message_bytes


def bytes_to_words(chunk):
    """Convert 64-byte chunk to 16 32-bit little-endian words"""
    words = []
    for i in range(0, 64, 4):
        word = int.from_bytes(chunk[i:i + 4], byteorder='little')
        words.append(word)
    return words


def F(b, c, d, i):
    if i < 16:
        return (b & c) | ((~b) & d)
    elif i < 32:
        return (d & b) | ((~d) & c)
    elif i < 48:
        return b ^ c ^ d
    else:
        return c ^ (b | (~d))


def left_rotation(x, r):
    return ((x << r) | (x >> (32 - r))) & 0xFFFFFFFF


def find_idx(i):
    if i < 16:
        return i
    elif i < 32:
        return (5 * i + 1) % 16
    elif i < 48:
        return (3 * i + 5) % 16
    else:
        return (7 * i) % 16


def md5(message):
    # Initialize buffers
    A = 0x67452301
    B = 0xEFCDAB89
    C = 0x98BADCFE
    D = 0x10325476

    # Constants
    K = [0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee, 0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
         0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be, 0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
         0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa, 0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
         0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed, 0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
         0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c, 0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
         0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05, 0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
         0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039, 0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
         0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1, 0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391]

    R = [7, 12, 17, 22] * 4 + [5, 9, 14, 20] * 4 + [4, 11, 16, 23] * 4 + [6, 10, 15, 21] * 4

    # Pad the message
    padded = bits_padding(message)

    # Process each 512-bit (64-byte) chunk
    for chunk_start in range(0, len(padded), 64):
        chunk = padded[chunk_start:chunk_start + 64]
        M = bytes_to_words(chunk)

        # Initialize working variables
        a, b, c, d = A, B, C, D

        # Main loop
        for i in range(64):
            f_val = F(b, c, d, i)
            idx = find_idx(i)
            temp = (a + f_val + K[i] + M[idx]) & 0xFFFFFFFF
            temp = left_rotation(temp, R[i])
            temp = (temp + b) & 0xFFFFFFFF

            # Rotate variables
            a, b, c, d = d, temp, b, c

        # Add this chunk's hash to result so far
        A = (A + a) & 0xFFFFFFFF
        B = (B + b) & 0xFFFFFFFF
        C = (C + c) & 0xFFFFFFFF
        D = (D + d) & 0xFFFFFFFF
    print()
    print(A,B,C,D)
    # Produce final hash value (little-endian)
    def to_little_endian_hex(x):
        return ''.join(format((x >> (8 * i)) & 0xFF, '02x') for i in range(4))

    return ''.join(to_little_endian_hex(x) for x in [A, B, C, D])


# Test
test_strings = ['a']

for test in test_strings:
    my_hash = md5(test.encode())
    lib_hash = hashlib.md5(test.encode()).hexdigest()
    match = "✓" if my_hash == lib_hash else "✗"
    print(f"{match} '{test}'")
    print(f"  Mine: {my_hash}")
    print(f"  Lib:  {lib_hash}")
    print()