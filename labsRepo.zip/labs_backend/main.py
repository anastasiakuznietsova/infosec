from fastapi import FastAPI, HTTPException, File, Form, UploadFile,status
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

from utils.rand_num_gen import pseudo_rand_num, to_test_generator
from utils.md5 import start_hashing,compare_hash
from pydantic import BaseModel


app = FastAPI()

origins = [
    "http://localhost",
    "http://localhost:8080",
    "http://localhost:4200"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

x = ""

@app.get("/")
async def root():
    return {"message": "Hello World"}


@app.get("/pseudo_rand_num")
async def calc_rand_num(n:int):
    global x
    x, period, seq = pseudo_rand_num(n)
    return {
        'sequence': seq,
        'period': period
    }

@app.get("/pseudo_rand_num/test")
async def rand_num_test():
    global x
    prob,prob_act,pi_est,pi_act = to_test_generator(x)
    return {
        "probability" : prob,
        "actualProbability" : prob_act,
        "PIestimate" : pi_est,
        "PIactual" : pi_act
    }

@app.post("/md5_hash")
async def md5_hash(
        inputStr: str = Form(None),
        inputFile: UploadFile = File(None)
):
    if inputStr is not None:
        content = inputStr
    elif inputFile is not None:
        content = await inputFile.read()
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Input wasn’t provided",
            headers={"X-Error": "Bad Request"}
        )

    hash_val = start_hashing(content)
    return {"hashValue": hash_val}

@app.post("/md5_hash/check_integrity")
async def check_integrity_hash(
        inputFile:UploadFile = File(None),
        controlFile:UploadFile = File(None)
):
    if inputFile:
        content = await inputFile.read()
        hash_compare = await controlFile.read()
        hash_compare = hash_compare.decode('utf-8')
    hash_val = start_hashing(content)
    compare_res = compare_hash(hash_val, hash_compare)
    return {
        "hashValue" : hash_val,
        "hashCompare": hash_compare,
        "integrityPassed" : compare_res
    }
